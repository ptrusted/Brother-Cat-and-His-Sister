
function loadImages ( ... )
    -- splash screen
    ImagesSplash = loadSpritesAnimImages('assets/sprites/splash/%d.png',1,31)
    -- main menu
    ImageBackground1 = love.graphics.newImage("assets/sprites/Main Menu Background.png")
    ImageTitle = love.graphics.newImage("assets/sprites/Title.png")
    ImagesWindow = loadSpritesAnimImages('assets/sprites/window/%d.png',1,22)
    ImagesCat = loadSpritesAnimImages('assets/sprites/cats/%d.png',1,8) -- pay attention to index
    ImagesCatName = loadSpritesAnimImages('assets/sprites/cats/names/%d.png',1,8) -- pay attention to index
    ImagesStar = loadSpritesAnimImages('assets/sprites/stars/%d.png',1,13)
    ImageArrowButton = love.graphics.newImage("assets/sprites/arrow button.png")
    ImagePlayButton = love.graphics.newImage("assets/sprites/play button.png")
    ImageLocked = love.graphics.newImage("assets/sprites/locked.png")
    -- gameplay
    ImagesBackground = loadSpritesAnimImages('assets/sprites/In Game Background %d.png',1,6)
    ImagesTutorial = loadSpritesAnimImages('assets/sprites/Tutorial %d.png',1,2)
    ImagesBall1 = loadSpritesAnimImages('assets/sprites/ball/%d.png',1,28)
    ImagesBall2 = loadSpritesAnimImages('assets/sprites/ball/%d.png',1,28)
    ImagesNice = loadSpritesAnimImages('assets/sprites/nice word/%d.png',1,18)
    ImagesNotBad = loadSpritesAnimImages('assets/sprites/not bad word/%d.png',1,18)
    ImagesMiss = loadSpritesAnimImages('assets/sprites/miss word/%d.png',1,21)
    ImageHealthBar = love.graphics.newImage("assets/sprites/Health bar.png")
    ImageHealth = love.graphics.newImage("assets/sprites/Health.png")
    ImageGameOver = love.graphics.newImage("assets/sprites/Game over.png")
    ImagesCharacters = {}
    local counter = 1
    for a = 1,8 do -- pay attention to index
        ImagesCharacters[a] = {}
        for b = 1,6 do
            ImagesCharacters[a][b] = love.graphics.newImage(string.format('assets/sprites/cat gestures/%d.png',counter))
            counter = counter + 1
        end
    end
end

function loadSounds ( ... )
    --splashTunes = love.audio.newSource('assets/splash tunes.ogg')
	BgSoundMainMenu = love.audio.newSource('assets/sounds/Main Menu.ogg','stream')
	BgSoundMainMenu:setLooping(true)
    BgSoundMainMenu:setVolume(0.4)
    BgSoundGameplay = love.audio.newSource('assets/sounds/Gameplay.ogg','stream')
	BgSoundGameplay:setLooping(true)
    BgSoundGameplay:setVolume(0.6)
    BgSoundGameOver = love.audio.newSource('assets/sounds/calming down.ogg','stream')
	BgSoundGameOver:setLooping(true)
    BgSoundGameOver:setVolume(1)
    SfxHorn = love.audio.newSource('assets/sounds/horn.ogg','static') -- 'static' used for sfx
	SfxHorn:setLooping(false)
    SfxHorn:setVolume(1)
    SfxIn = love.audio.newSource('assets/sounds/in.ogg','static') -- 'static' used for sfx
	SfxIn:setLooping(false)
    SfxIn:setVolume(1)
    SfxOut = love.audio.newSource('assets/sounds/out.ogg','static') -- 'static' used for sfx
	SfxOut:setLooping(false)
    SfxOut:setVolume(1)
    SfxWin = love.audio.newSource('assets/sounds/win.ogg','static') -- 'static' used for sfx
	SfxWin:setLooping(false)
    SfxWin:setVolume(1)
    SfxLose = love.audio.newSource('assets/sounds/lose.ogg','static') -- 'static' used for sfx
	SfxLose:setLooping(false)
    SfxLose:setVolume(1)
    SfxGameOver = love.audio.newSource('assets/sounds/game over.ogg','static') -- 'static' used for sfx
	SfxGameOver:setLooping(false)
    SfxGameOver:setVolume(1)
    SfxBall1 = love.audio.newSource('assets/sounds/ball.ogg','static') -- 'static' used for sfx
	SfxBall1:setLooping(false)
    SfxBall1:setVolume(0.2)
    SfxBall2 = love.audio.newSource('assets/sounds/ball.ogg','static') -- 'static' used for sfx
	SfxBall2:setLooping(false)
    SfxBall2:setVolume(0.2)
end

function loadFonts ( ... )
    FontCalibri = love.graphics.newFont("assets/fonts/calibriz.ttf",42)
    love.graphics.setFont (FontCalibri)

    -- messages to player printed in console
    print(' \n\n Thanks for playing the game,\n in pc version you can use (A) and (D) button to select character and jump \n press (enter) to immitate the touch')
    --
end

function createGlobalVariables ()
    Scenes = {SplashScreenScene, MainMenuScene, InGameScene}
    CounterSelectedScene = 1
    CounterTimer = 0
    -- -----------------------------------------------------------------
    ChoosenCat = 1
    TotalCat = 8 -- pay attention to index
    Highscore = {} -- this variable should be saved
        for a = 1, TotalCat do
            Highscore[a] = 0
        end
    UnlockedCat = 1
    dificulty = {{0.4,0.1},{0.6,0.12},{0.8,0.13},{1,0.14},{2,0.15},{3,0.2},{4,0.25},{5,0.3}} -- play time, health increase factor
    
    loadSavedVariables()
end

-- ---------------------------------------------------------------------------- other functions

function checkUnlockedCats ()
    for i = 1,TotalCat-1 do
        if Highscore[i] >= 10000 then
            UnlockedCat = i + 1
        end
    end
end

function loadSavedVariables ()
    -- if the file doesn't exist, we should create it first
    local exist = love.filesystem.exists('progress.txt')
    --print(love.filesystem.getSaveDirectory() .. '/progress.txt')
    if exist then
        -- read it all the way and pass it to proper global variables
        local extractedData = extractDataFromFile ('progress.txt','###') 
        compareExtractedDataWithGlobalVariable(Highscore,extractedData)
    else
        -- create file
        saveProgress()
    end
end

function loadSpritesAnimImages (nameFormat,startIndex,finishIndex)
    local theImages = {}
	for i=startIndex,finishIndex do
		theImages[i] = love.graphics.newImage(string.format(nameFormat,i))
	end

    return theImages
end

function saveProgress ()
    local FileToSave = love.filesystem.newFile('progress.txt') 
    FileToSave:open('w')

    local dataToSave = ''
    for a,b in ipairs(Highscore) do
        dataToSave = dataToSave .. b .. '###'
    end

    FileToSave:write(dataToSave)
    FileToSave:close()
end

function extractDataFromFile (fileName,parser)
    local savedData = love.filesystem.read(fileName) -- we got the data
    local extractedData = {} -- this is where we store the extracted data
    local dataCounter = 1
    local startIndex,endIndex = string.find(savedData,parser) -- startIndex is where we begin the search until the parser found
    local tempIndex = 1 -- extra variable needed
    while startIndex do
        extractedData[dataCounter] = string.sub(savedData,tempIndex,startIndex-1)
        dataCounter = dataCounter + 1
        tempIndex = endIndex + 1
        startIndex,endIndex = string.find(savedData,parser,tempIndex)
    end
    
    return extractedData
end

function compareExtractedDataWithGlobalVariable (globalVariable,extractedData)
    if #globalVariable == #extractedData then
        for i=1,#globalVariable do
            globalVariable[i] = tonumber(extractedData[i])
        end
        return true
    else
        for i=1,#globalVariable do
            globalVariable[i] = 0
        end
        return false
    end
end