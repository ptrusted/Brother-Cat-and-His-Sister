
InGameScene = {}

    InGameScene.initialize = function ()
        InGameScene.backgroundIndex = love.math.random(1,6)

        InGameScene.dificulty = dificulty[ChoosenCat]
        InGameScene.gamePlayed = false
        InGameScene.gameOver = false
        InGameScene.playTime = InGameScene.dificulty[1]
        InGameScene.score = 0
        -- ------------------------------------------------------------------------ game objects creation
        InGameScene.gameObjects = {}
            InGameScene.gameObjects[1] = createGameObject(
                    true,
                    "brother cat",
                    ImagesCharacters[ChoosenCat][1],
                    love.graphics.getWidth()/2-100,love.graphics.getHeight()-55,
                    0,1,1,
                    ImagesCharacters[ChoosenCat][1]:getWidth()/2,ImagesCharacters[ChoosenCat][1]:getHeight()
                )
                -- ------------------------------------------------------------------------ animation
                InGameScene.gameObjects[1].animation = true
                InGameScene.gameObjects[1].animator = createScalingAnimator(InGameScene.gameObjects[1],false,1,0.95,1,1,0.001)
                -- ------------------------------------------------------------------------ behaviour
                InGameScene.gameObjects[1].behaviour = {}
                InGameScene.gameObjects[1].behaviour.timer = 0.15
                InGameScene.gameObjects[1].behaviour.switch = false
                InGameScene.gameObjects[1].behaviour.update = function ()
                    if InGameScene.gameObjects[1].behaviour.switch then
                        if InGameScene.gameObjects[1].behaviour.timer > 0 then
                            InGameScene.gameObjects[1].behaviour.timer = InGameScene.gameObjects[1].behaviour.timer - love.timer.getDelta()
                        else
                            InGameScene.gameObjects[1].behaviour.timer = 0.15
                            InGameScene.gameObjects[1].behaviour.idle()
                            InGameScene.gameObjects[1].behaviour.switch = false
                        end
                    end
                end
                InGameScene.gameObjects[1].behaviour.idle = function ()
                    InGameScene.gameObjects[1].image = ImagesCharacters[ChoosenCat][1]
                    InGameScene.gameObjects[1].offsetX = ImagesCharacters[ChoosenCat][1]:getWidth()/2
                    InGameScene.gameObjects[1].offsetY = ImagesCharacters[ChoosenCat][1]:getHeight()
                end
                InGameScene.gameObjects[1].behaviour.jump = function ()
                    SfxIn:stop()
                    SfxIn:play()
                    InGameScene.checkScore(1)
                    InGameScene.gameObjects[1].image = ImagesCharacters[ChoosenCat][2]
                    InGameScene.gameObjects[1].offsetX = ImagesCharacters[ChoosenCat][2]:getWidth()/2
                    InGameScene.gameObjects[1].offsetY = ImagesCharacters[ChoosenCat][2]:getHeight()
                    InGameScene.gameObjects[1].behaviour.switch = true
                end
                InGameScene.gameObjects[1].behaviour.annoyed = function ()
                    InGameScene.gameObjects[1].image = ImagesCharacters[ChoosenCat][3]
                    InGameScene.gameObjects[1].positionX = love.graphics.getWidth()/2-50
                    InGameScene.gameObjects[1].offsetX = ImagesCharacters[ChoosenCat][3]:getWidth()/2
                    InGameScene.gameObjects[1].offsetY = ImagesCharacters[ChoosenCat][3]:getHeight()
                end
            InGameScene.gameObjects[2] = createGameObject(
                    true,
                    "sister cat",
                    ImagesCharacters[ChoosenCat][4],
                    love.graphics.getWidth()/2+100,love.graphics.getHeight()-55,
                    0,1,1,
                    ImagesCharacters[ChoosenCat][4]:getWidth()/2,ImagesCharacters[ChoosenCat][4]:getHeight()
                )
                -- ------------------------------------------------------------------------ animation
                InGameScene.gameObjects[2].animation = true
                InGameScene.gameObjects[2].animator = createScalingAnimator(InGameScene.gameObjects[2],false,1,0.95,1,1,0.001)
                -- ------------------------------------------------------------------------ behaviour
                InGameScene.gameObjects[2].behaviour = {}
                InGameScene.gameObjects[2].behaviour.timer = 0.15
                InGameScene.gameObjects[2].behaviour.switch = false
                InGameScene.gameObjects[2].behaviour.update = function ()
                    if InGameScene.gameObjects[2].behaviour.switch then
                        if InGameScene.gameObjects[2].behaviour.timer > 0 then
                            InGameScene.gameObjects[2].behaviour.timer = InGameScene.gameObjects[2].behaviour.timer - love.timer.getDelta()
                        else
                            InGameScene.gameObjects[2].behaviour.timer = 0.15
                            InGameScene.gameObjects[2].behaviour.idle()
                            InGameScene.gameObjects[2].image = ImagesCharacters[ChoosenCat][4]
                            InGameScene.gameObjects[2].offsetY = ImagesCharacters[ChoosenCat][4]:getHeight()
                            InGameScene.gameObjects[2].behaviour.switch = false
                        end
                    end
                end
                InGameScene.gameObjects[2].behaviour.idle = function ()
                    InGameScene.gameObjects[2].image = ImagesCharacters[ChoosenCat][4]
                    InGameScene.gameObjects[2].offsetX = ImagesCharacters[ChoosenCat][4]:getWidth()/2
                    InGameScene.gameObjects[2].offsetY = ImagesCharacters[ChoosenCat][4]:getHeight()
                end
                InGameScene.gameObjects[2].behaviour.jump = function ()
                    SfxIn:stop()
                    SfxIn:play()
                    InGameScene.checkScore(2)
                    InGameScene.gameObjects[2].image = ImagesCharacters[ChoosenCat][5]
                    InGameScene.gameObjects[2].offsetX = ImagesCharacters[ChoosenCat][5]:getWidth()/2
                    InGameScene.gameObjects[2].offsetY = ImagesCharacters[ChoosenCat][5]:getHeight()
                    InGameScene.gameObjects[2].behaviour.switch = true
                end
                InGameScene.gameObjects[2].behaviour.annoyed = function ()
                    InGameScene.gameObjects[2].image = ImagesCharacters[ChoosenCat][6]
                    InGameScene.gameObjects[2].positionX = love.graphics.getWidth()/2+50
                    InGameScene.gameObjects[2].offsetX = ImagesCharacters[ChoosenCat][6]:getWidth()/2
                    InGameScene.gameObjects[2].offsetY = ImagesCharacters[ChoosenCat][6]:getHeight()
                end
            InGameScene.gameObjects[3] = createGameObject(
                    true,
                    "health bar",
                    ImageHealthBar,
                    love.graphics.getWidth()/2,50,
                    0,1,1,
                    ImageHealthBar:getWidth()/2,ImageHealthBar:getHeight()/2
                )
            InGameScene.gameObjects[4] = createGameObject(
                    true,
                    "health",
                    ImageHealth,
                    love.graphics.getWidth()/2,50,
                    0,1,1,
                    ImageHealth:getWidth()/2,ImageHealth:getHeight()/2
                )
                InGameScene.gameObjects[4].animation = false
                InGameScene.gameObjects[4].animator = createScalingAnimator(InGameScene.gameObjects[4],false,-0.01,1,1,1,InGameScene.playTime/1000)
            InGameScene.gameObjects[5] = createGameObject(
                    true,
                    "tutorial",
                    ImagesTutorial[1],
                    love.graphics.getWidth()/2,love.graphics.getHeight()/2,
                    0,1,1,
                    ImagesTutorial[1]:getWidth()/2,ImagesTutorial[1]:getHeight()/2
                )
            InGameScene.gameObjects[6] = createGameObject(
                    false,
                    "game over",
                    ImageGameOver,
                    love.graphics.getWidth()/2,210,
                    0,1,1,
                    ImageGameOver:getWidth()/2,ImageGameOver:getHeight()/2
                )
                InGameScene.gameObjects[6].animation = true
                InGameScene.gameObjects[6].animator = createScalingAnimator(InGameScene.gameObjects[6],true,0.9,0.9,0.97,0.97,0.005)
            InGameScene.gameObjects[7] = createGameObject(
                    true,
                    "ball",
                    ImagesBall1[1],
                    love.graphics.getWidth()/2,love.graphics.getHeight()+20,
                    0,1,1,
                    ImagesBall1[1]:getWidth()/2,ImagesBall1[1]:getHeight()
                )
                InGameScene.gameObjects[7].animation = false
                InGameScene.gameObjects[7].animator = createSpriteAnimator(InGameScene.gameObjects[7],0.01,false,ImagesBall1,1,28,SfxBall1)
            InGameScene.gameObjects[8] = createGameObject(
                    true,
                    "ball",
                    ImagesBall2[1],
                    love.graphics.getWidth()/2,love.graphics.getHeight()+20,
                    0,-0.75,0.75,
                    ImagesBall2[1]:getWidth()/2,ImagesBall2[1]:getHeight()
                )
                InGameScene.gameObjects[8].animation = false
                InGameScene.gameObjects[8].animator = createSpriteAnimator(InGameScene.gameObjects[8],0.01,false,ImagesBall2,1,28,SfxBall2)
            InGameScene.gameObjects[9] = createGameObject(
                    true,
                    "nice",
                    ImagesNice[1],
                    love.graphics.getWidth()/2,love.graphics.getHeight()/2+35,
                    0,1,1,
                    ImagesNice[1]:getWidth()/2,ImagesNice[1]:getHeight()/2
                )
                InGameScene.gameObjects[9].animation = false
                InGameScene.gameObjects[9].animator = createSpriteAnimator(InGameScene.gameObjects[9],0.01,false,ImagesNice,1,18,SfxWin)
            InGameScene.gameObjects[10] = createGameObject(
                    true,
                    "miss",
                    ImagesMiss[1],
                    love.graphics.getWidth()/2,love.graphics.getHeight()/2,
                    0,1,1,
                    ImagesMiss[1]:getWidth()/2,ImagesMiss[1]:getHeight()/2
                )
                InGameScene.gameObjects[10].animation = false
                InGameScene.gameObjects[10].animator = createSpriteAnimator(InGameScene.gameObjects[10],0.01,false,ImagesMiss,1,21,SfxLose)
            InGameScene.gameObjects[11] = createGameObject(
                    true,
                    "not bad",
                    ImagesNotBad[1],
                    love.graphics.getWidth()/2,love.graphics.getHeight()/2+35,
                    0,1,1,
                    ImagesNotBad[1]:getWidth()/2,ImagesNotBad[1]:getHeight()/2
                )
                InGameScene.gameObjects[11].animation = false
                InGameScene.gameObjects[11].animator = createSpriteAnimator(InGameScene.gameObjects[11],0.01,false,ImagesNotBad,1,18,SfxWin)
        -- ------------------------------------------------------------------------
        InGameScene.usingTimer = true
        InGameScene.sequenceExecution = coroutine.create(
            function ()
                coroutine.yield(2)
                InGameScene.gameObjects[5].image = ImagesTutorial[2]
                coroutine.yield(2.5)
                InGameScene.gameObjects[5].active = false
                InGameScene.gameObjects[4].animation = true -- start decreasing Health
                InGameScene.gamePlayed = true
                InGameScene.usingTimer = false
            end
        )
    end

    -- ---------------------------------------------------------------------------- main functions

    InGameScene.draw = function ()
        InGameScene.setBackground()
        InGameScene.drawImages()
        InGameScene.drawUI()
    end

    InGameScene.update = function ()
        if not InGameScene.gameOver then
            InGameScene.gameRules()
            InGameScene.throwBall()
        end
    end

    InGameScene.listenerKeyPressed = function (key)
        if key=="escape" or (key=="return" and InGameScene.gameOver) then
            BgSoundGameplay:stop()
            BgSoundGameOver:stop()
            changeScene(1)
        elseif key=="a" and InGameScene.gamePlayed and not InGameScene.gameOver then
            InGameScene.gameObjects[1].behaviour.jump()
        elseif key=="d" and InGameScene.gamePlayed and not InGameScene.gameOver then
            InGameScene.gameObjects[2].behaviour.jump()
        end
    end

    InGameScene.listenerTouchPressed = function (id, x, y, dx, dy, pressure)
        if InGameScene.gamePlayed and not InGameScene.gameOver then
            if x>love.graphics.getWidth()/2+50 then
                InGameScene.gameObjects[2].behaviour.jump()
            elseif x<love.graphics.getWidth()/2-50 then
                InGameScene.gameObjects[1].behaviour.jump()
            end
        elseif y<460 and InGameScene.gameOver and InGameScene.gamePlayed then
            BgSoundGameOver:stop()
            changeScene(1)
        end
    end

    -- ---------------------------------------------------------------------------- other functions

    InGameScene.setBackground = function ()
        love.graphics.setBackgroundColor( 40, 40, 40 )
        love.graphics.draw(ImagesBackground[InGameScene.backgroundIndex], love.graphics.getWidth()/2 ,love.graphics.getHeight()/2,0,love.graphics.getWidth()/480,love.graphics.getWidth()/480,ImagesBackground[InGameScene.backgroundIndex]:getWidth()/2,ImagesBackground[InGameScene.backgroundIndex]:getHeight()/2)
    end

    InGameScene.drawImages = function ()
        if InGameScene.gameObjects then
            for a,b in ipairs(InGameScene.gameObjects) do
                if b.active then
                    love.graphics.draw(b.image, b.positionX ,b.positionY,b.rotation,b.scaleX,b.scaleY,b.offsetX,b.offsetY)
                    if b.animation and b.animator then
                        b.animator.updateAnimator()
                    end
                    if b.behaviour then
                        b.behaviour.update()
                    end
                end
            end
        end
    end
    
    InGameScene.drawUI = function ()
        if InGameScene.gamePlayed then
            love.graphics.printf(InGameScene.score, love.graphics.getWidth()/2, 100, 480,"center",0,2,2,240,0) -- score
        end
    end

    InGameScene.gameRules = function ()
        if InGameScene.gameObjects[4].scaleX < 0 then
            InGameScene.gameIsOver()
        end
    end

    InGameScene.throwBall = function ()
        if not InGameScene.gameObjects[7].animation and not InGameScene.gameObjects[8].animation and InGameScene.gamePlayed then
            local index = love.math.random(1,2)
            InGameScene.gameObjects[6+index].animator.play(1,28)
        end
    end

    InGameScene.gameIsOver = function ()
        InGameScene.gameObjects[1].behaviour.annoyed()
        InGameScene.gameObjects[2].behaviour.annoyed()
        InGameScene.gameOver = true
        InGameScene.gameObjects[4].animation = false
        InGameScene.gameObjects[4].scaleX = 0
        InGameScene.gameObjects[6].active = true
        BgSoundGameplay:stop()
        SfxGameOver:play()
        BgSoundGameOver:play()
        -- saving progress
        saveProgress()
        -- 
    end

    InGameScene.checkScore = function (playerIndex)
        if InGameScene.gameObjects[6+playerIndex].animator.currentFrame == 16 or InGameScene.gameObjects[6+playerIndex].animator.currentFrame == 17 then
            InGameScene.increaseScore(playerIndex,true)
        elseif InGameScene.gameObjects[6+playerIndex].animator.currentFrame >= 18 and InGameScene.gameObjects[6+playerIndex].animator.currentFrame <= 20 then
            InGameScene.increaseScore(playerIndex,false)
        else
            InGameScene.decreaseHealth()
        end
    end

    InGameScene.increaseScore = function (playerIndex,topScore)
        local score = 0
        if topScore then
            score = 100
            InGameScene.gameObjects[9].animator.play(1,18) -- play complimentation animation
        else
            score = 50
            InGameScene.gameObjects[11].animator.play(1,18) -- play complimentation animation
        end
        
        InGameScene.gameObjects[6+playerIndex].animation = false -- stop current ball animation
        InGameScene.gameObjects[6+playerIndex].image = ImagesBall1[1] -- hides ball object
        InGameScene.gameObjects[6+playerIndex].animator.currentFrame = 0 -- reset the animation frame counter

        InGameScene.score = InGameScene.score + score
        if InGameScene.score > Highscore[ChoosenCat] then
            Highscore[ChoosenCat] = InGameScene.score
        end
        if InGameScene.gameObjects[4].scaleX > 0 and InGameScene.gameObjects[4].scaleX < 1 then -- increase health
            InGameScene.gameObjects[4].scaleX = InGameScene.gameObjects[4].scaleX + InGameScene.dificulty[2]
            if InGameScene.gameObjects[4].scaleX > 1 then
                InGameScene.gameObjects[4].scaleX = 1
            end
        end
    end

    InGameScene.decreaseHealth = function ()
        InGameScene.gameObjects[10].animator.play(1,21)
        if InGameScene.gameObjects[4].scaleX > 0.1 and InGameScene.gameObjects[4].scaleX < 1 then
            InGameScene.gameObjects[4].scaleX = InGameScene.gameObjects[4].scaleX - 0.1
        end
    end