MainMenuScene = {}

    MainMenuScene.initialize = function ()
        checkUnlockedCats()
        -- ------------------------------------------------------------------- variables

        -- ------------------------------------------------------------------- objects creations
        MainMenuScene.gameObjects = {}
            MainMenuScene.gameObjects[1] = createGameObject(
                true,
                "game title",
                ImageTitle,
                love.graphics.getWidth()/2,10,
                0,1,1,
                ImageTitle:getWidth()/2,0
            )
            MainMenuScene.gameObjects[1].animation = true
            MainMenuScene.gameObjects[1].animator = createScalingAnimator(MainMenuScene.gameObjects[1],true,0.9,0.9,1,1,0.001)

            MainMenuScene.gameObjects[2] = createGameObject(
                true,
                "play direction",
                ImagePlayButton,
                love.graphics.getWidth()/2,love.graphics.getHeight()-20,
                0,1,1,
                ImagePlayButton:getWidth()/2,ImagePlayButton:getHeight()/2
            )
            MainMenuScene.gameObjects[2].animation = true
            MainMenuScene.gameObjects[2].animator = createScalingAnimator(MainMenuScene.gameObjects[2],false,0.9,0.9,1,1,0.001)

            MainMenuScene.gameObjects[3] = createGameObject(
                true,
                "arrow",
                ImageArrowButton,
                love.graphics.getWidth()/2,love.graphics.getHeight()-160,
                0,1,1,
                ImageArrowButton:getWidth()/2,ImageArrowButton:getHeight()/2
            )
            MainMenuScene.gameObjects[3].animation = true
            MainMenuScene.gameObjects[3].animator = createScalingAnimator(MainMenuScene.gameObjects[3],false,0.8,0.8,1,1,0.01)

            MainMenuScene.gameObjects[4] = createGameObject(
                true,
                "cats",
                ImagesCat[ChoosenCat],
                love.graphics.getWidth()/2,love.graphics.getHeight()-40,
                0,1,1,
                ImagesCat[ChoosenCat]:getWidth()/2,ImagesCat[ChoosenCat]:getHeight()
            )
            MainMenuScene.gameObjects[4].animation = true
            MainMenuScene.gameObjects[4].animator = createScalingAnimator(MainMenuScene.gameObjects[4],false,1,0.95,1,1,0.001)

            MainMenuScene.gameObjects[5] = createGameObject(
                true,
                "window",
                ImagesWindow[1],
                love.graphics.getWidth()/2,260,
                0,1,1,
                ImagesWindow[1]:getWidth()/2,0
            )
            MainMenuScene.gameObjects[5].animation = true
            MainMenuScene.gameObjects[5].animator = createSpriteAnimator(MainMenuScene.gameObjects[5],0.5,true,ImagesWindow,1,22)

            MainMenuScene.gameObjects[6] = createGameObject(
                true,
                "star",
                ImagesStar[1],
                love.graphics.getWidth()/2,love.graphics.getHeight()-70,
                0,1,1,
                ImagesStar[1]:getWidth()/2,ImagesStar[1]:getHeight()
            )
            MainMenuScene.gameObjects[6].animation = false
            MainMenuScene.gameObjects[6].animator = createSpriteAnimator(MainMenuScene.gameObjects[6],0.01,false,ImagesStar,1,13)

            MainMenuScene.gameObjects[7] = createGameObject(
                true,
                "cat names",
                ImagesCatName[ChoosenCat],
                love.graphics.getWidth()/2-100,love.graphics.getHeight()-220,
                0,1,1,
                ImagesCatName[ChoosenCat]:getWidth(),ImagesCatName[ChoosenCat]:getHeight()
            )
            MainMenuScene.gameObjects[7].animation = true
            MainMenuScene.gameObjects[7].animator = createScalingAnimator(MainMenuScene.gameObjects[7],false,0.85,0.85,1,1,0.005)

            MainMenuScene.gameObjects[8] = createGameObject(
                true,
                "star",
                ImagesStar[1],
                love.graphics.getWidth()/2,120,
                0,1,-0.6,
                ImagesStar[1]:getWidth()/2,ImagesStar[1]:getHeight()
            )
            MainMenuScene.gameObjects[8].animation = false
            MainMenuScene.gameObjects[8].animator = createSpriteAnimator(MainMenuScene.gameObjects[8],0.01,false,ImagesStar,1,13)
            
            MainMenuScene.gameObjects[9] = createGameObject(
                false,
                "locked",
                ImageLocked,
                love.graphics.getWidth()/2,love.graphics.getHeight()-40,
                0,1,1,
                ImageLocked:getWidth()/2,ImageLocked:getHeight()
            )        
    end

    -- ---------------------------------------------------------------------------- main functions

    MainMenuScene.draw = function ()
        MainMenuScene.setBackground()
        MainMenuScene.drawImages()
    end

    MainMenuScene.update = function ()
        
    end

    MainMenuScene.listenerKeyPressed = function (key)
        if key=="return" then
            MainMenuScene.startTheGame()
        elseif key=="escape" then
            love.event.quit()
        elseif key=="a" then
            MainMenuScene.chooseCat('left')
        elseif key=="d" then
            MainMenuScene.chooseCat('right')
        end
    end

    MainMenuScene.listenerTouchPressed = function(id, x, y, dx, dy, pressure)
        if x>love.graphics.getWidth()/2+50 and y<love.graphics.getHeight()-100 then
            MainMenuScene.chooseCat('right')
        elseif x<love.graphics.getWidth()/2-50 and y<love.graphics.getHeight()-100 then
            MainMenuScene.chooseCat('left')
        elseif y>love.graphics.getHeight()-100 then
            MainMenuScene.startTheGame()
        end
    end

    -- ---------------------------------------------------------------------------- other functions

    MainMenuScene.setBackground = function ()
        love.graphics.setBackgroundColor( 40, 40, 40 )
        love.graphics.draw(ImageBackground1, love.graphics.getWidth()/2 ,love.graphics.getHeight()/2,0,love.graphics.getWidth()/480,love.graphics.getWidth()/480,ImageBackground1:getWidth()/2,ImageBackground1:getHeight()/2)
        love.graphics.printf("Developed by\nptrusted in\nNovember 2016\nusing LOVE2D.", 5, 10, 240,"left",0,0.35,0.35) -- text credit
        love.graphics.printf("Big credits to :\nLOVE2D.org,\nGIMP.org,\nInkscape.org,\nlmms.io", love.graphics.getWidth()-5, 10, 240,"right",0,0.35,0.35,240,0) -- text credit
        local highScoreToPrint = string.format( "Highscore : %d",Highscore[ChoosenCat])
        love.graphics.printf(highScoreToPrint, love.graphics.getWidth()/2, 200, 400,"center",0,1,1,200,0) -- score
    end

    MainMenuScene.drawImages = function ()
        if MainMenuScene.gameObjects then
            for a,b in ipairs(MainMenuScene.gameObjects) do
                if b.active then
                    love.graphics.draw(b.image, b.positionX ,b.positionY,b.rotation,b.scaleX,b.scaleY,b.offsetX,b.offsetY)
                    if b.animation and b.animator then
                        b.animator.updateAnimator()
                    end
                    if b.behaviour then
                        b.behaviour()
                    end
                end
            end
        end
    end

    MainMenuScene.chooseCat = function (key)
        if key == 'left' then
            if ChoosenCat > 1 then
                ChoosenCat = ChoosenCat - 1
                MainMenuScene.gameObjects[6].animator.play(1,13)
                MainMenuScene.gameObjects[8].animator.play(1,13)
            end
            SfxOut:stop()
            SfxOut:play()
        elseif key == 'right' then
            if ChoosenCat < TotalCat then
                ChoosenCat = ChoosenCat + 1
                MainMenuScene.gameObjects[6].animator.play(1,13)
                MainMenuScene.gameObjects[8].animator.play(1,13)
            end
            SfxIn:stop()
            SfxIn:play()
        end
        if ChoosenCat > UnlockedCat then -- locked
            MainMenuScene.gameObjects[9].active = true
        else
            MainMenuScene.gameObjects[9].active = false
        end
        MainMenuScene.gameObjects[4].image = ImagesCat[ChoosenCat]
        MainMenuScene.gameObjects[4].offsetX = ImagesCat[ChoosenCat]:getWidth()/2
        MainMenuScene.gameObjects[4].offsetY = ImagesCat[ChoosenCat]:getHeight()
        MainMenuScene.gameObjects[7].image = ImagesCatName[ChoosenCat]
    end

    MainMenuScene.startTheGame = function ()
        BgSoundMainMenu:stop()
        BgSoundGameplay:play()
        if ChoosenCat > UnlockedCat then
            ChoosenCat = UnlockedCat
        end
        changeScene(3)
    end