
SplashScreenScene = {}

    SplashScreenScene.initialize = function()
        SplashScreenScene.gameObjects = {}
        SplashScreenScene.gameObjects[1] = createGameObject(
            true,
            "splash icon",
            ImagesSplash[1],
            love.graphics.getWidth()/2,
            love.graphics.getHeight()/2,
            0,1,1,
            ImagesSplash[1]:getWidth()/2,
            ImagesSplash[1]:getHeight()/2
        )
        SplashScreenScene.gameObjects[1].animation = false
        SplashScreenScene.gameObjects[1].animator = createSpriteAnimator(SplashScreenScene.gameObjects[1],0.05,false,ImagesSplash,1,31,SfxHorn)
        
        SplashScreenScene.usingTimer = true
        SplashScreenScene.sequenceExecution = coroutine.create(
            function ()
                SplashScreenScene.gameObjects[1].animator.play(1,31)
                coroutine.yield(2.5)
                changeScene(2)
                BgSoundMainMenu:play()
            end
        )
    end

    -- ---------------------------------------------------------------------------- main functions

    SplashScreenScene.draw = function()
        SplashScreenScene.setBackground()
        SplashScreenScene.drawImages()
    end

    SplashScreenScene.update = function()

    end

    SplashScreenScene.listenerKeyPressed = function(key)
        -- if key=="return" then
        --     changeScene(2)
        -- end
    end

    SplashScreenScene.listenerTouchPressed = function(id, x, y, dx, dy, pressure)
        -- if id == 0 then
        --     changeScene(2)
        -- end
    end

    -- ---------------------------------------------------------------------------- other functions

    SplashScreenScene.setBackground = function()
        love.graphics.setBackgroundColor( 255, 255, 255 )
    end

    SplashScreenScene.drawImages = function ()
        if SplashScreenScene.gameObjects then
            for a,b in ipairs(SplashScreenScene.gameObjects) do
                if b.active then
                    love.graphics.draw(b.image, b.positionX ,b.positionY,b.rotation,b.scaleX,b.scaleY,b.offsetX,b.offsetY)
                    if b.animation and b.animator then
                        b.animator.updateAnimator()
                    end
                    if b.behaviour then
                        b.behaviour()
                    end
                end
            end
        end
    end